Iron Man (Easy Print) by borntobeathug on Thingiverse: https://www.thingiverse.com/thing:3584233

Summary:
Printing one piece required too much material. I made the printing more comfortable by dividing the model. In this way, we will be able to print using less support.Print the body with 0 infill. Other parts can be printed with 10 percent infill. For this piece the 0.2 mm layer height came up enough.I recommend that you print the leg and the body vertically, and the hands horizontally. I got a good result with 250 percent scale printing.